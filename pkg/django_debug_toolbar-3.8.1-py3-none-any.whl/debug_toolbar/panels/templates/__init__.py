from debug_toolbar.panels.templates.panel import TemplatesPanel

__all__ = ["TemplatesPanel"]
