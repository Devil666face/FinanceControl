# coding: utf-8


__version__ = '0.19.8'
__version_info__ = (0, 19, 8)
